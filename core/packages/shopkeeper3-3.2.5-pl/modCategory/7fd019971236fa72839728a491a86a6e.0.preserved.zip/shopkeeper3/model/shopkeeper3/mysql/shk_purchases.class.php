<?php
require_once (dirname(dirname(__FILE__)) . '/shk_purchases.class.php');
class shk_purchases_mysql extends shk_purchases {}